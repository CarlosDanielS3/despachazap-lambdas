import bodyParser from "body-parser";
import dotenv from "dotenv";
import express from "express";

dotenv.config();
const app = express();

const port = 3001;
app.use(bodyParser.json());

export const handler = async (event) => {
  const { plate } = JSON.parse(event.body);
  console.log(plate);

  const isValidPlate = /^[A-Z]{3}[0-9][A-Z][0-9]{2}$/.test(plate.toUpperCase());

  return {
    statusCode: 200,
    body: JSON.stringify({ isValidPlate: String(isValidPlate) }),
  };
};

app.listen(port, () => {
  console.log(`app running on port ${port}`);
});
